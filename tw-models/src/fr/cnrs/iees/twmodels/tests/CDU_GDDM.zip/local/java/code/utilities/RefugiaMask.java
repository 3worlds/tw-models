package code.utilities;

import java.util.Random;

import au.edu.anu.rscs.aot.collections.tables.BooleanTable;

public class RefugiaMask {
	private RefugiaMask() {
	};


	public static void buildMask(BooleanTable refugia, int opt, boolean clumped, Random rng) {
		if (opt == 0)
			return;
		int maxx = refugia.size(0);
		int maxy = refugia.size(1);
		if (!clumped) {
			// fraction of the landscape to mask
			double fraction = 0.05;
			if (opt == 2)
				fraction = 0.2;
			for (int x = 0; x < maxx; x++)
				for (int y = 0; y < maxy; y++)
					if (rng.nextDouble()<fraction)
					refugia.setByInt(true, x, y);
			return;
		}
		// clumped
		int size = 22; // dim of refugia
		if (opt == 1) {
			// one square in random position
			int ox = rng.nextInt(maxx);
			int oy = rng.nextInt(maxy);
			for (int x = 0; x < size; x++)
				for (int y = 0; y < size; y++) {
					int xWrap = (x + ox) % maxx;
					int yWrap = (y + oy) % maxy;
					refugia.setByInt(true, xWrap, yWrap);
				}
			return;
		}
		// opt ==2: four randomly placed non-overlaping squares
		// for each quadrant
		for (int xq = 0;xq<2;xq++)
			for (int yq = 0; yq<2;yq++) {
				int ox = xq * (maxx / 2) + rng.nextInt(maxx / 4);
				int oy = yq * (maxy / 2) + rng.nextInt(maxy / 4);
				for (int x = 0; x < size; x++)
					for (int y = 0; y < size; y++) {
						int xWrap = (x + ox) % maxx;
						int yWrap = (y + oy) % maxy;
						refugia.setByInt(true, xWrap, yWrap);
					}
			}
	};

}
