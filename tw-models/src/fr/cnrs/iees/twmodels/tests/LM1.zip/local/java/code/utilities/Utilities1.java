package code.utilities;

public class Utilities1 {
	private Utilities1() {
	};

	// Dimensioners are not passed to init functions. Therefore, update these if
	// they are changed.
	public static final double landscapeWidth = 10000.0;
	public static final double landscapeHeight = 10000.0;
	public static final double habitatCellSize = 100.0;
	
	public static int gridLocation(double x,int extent, double gridSize) {
		int result = (int)(x/gridSize);
		result = result % extent;
		if (result<0)
			result += extent;
		return result;
	}

}
