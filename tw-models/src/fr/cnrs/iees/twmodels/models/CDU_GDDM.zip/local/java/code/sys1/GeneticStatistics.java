package code.sys1;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class GeneticStatistics {
	final List<List<Long>> pool;
	final List<Map<Long, Integer>> alleleSums;

	private GeneticStatistics(int nLoci) {
		this.pool = new ArrayList<>();
		alleleSums = new ArrayList<>();
		for (int locus = 0; locus < nLoci; locus++) {
			pool.add(new ArrayList<Long>());
			alleleSums.add(new HashMap<Long, Integer>());
		}
	}

	private void recordAllele(int locus, long allele) {
		List<Long> alleleValues = pool.get(locus);
		alleleValues.add(allele);
		Map<Long, Integer> sums = alleleSums.get(locus);
		Integer sum = 0;
		if (sums.containsKey(allele))
			sum = sums.get(allele);
		sum++;
		sums.put(allele, sum);
	}

	public double[] getHeterozygosity(int locus) {
		double[] result = new double[2];
		List<Long> alleleValues = pool.get(locus);
		double n = alleleValues.size();
		Map<Long, Integer> sums = alleleSums.get(locus);
		double sumSqrs = 0;
		for (Map.Entry<Long, Integer> entry : sums.entrySet()) {
			Integer sum = entry.getValue();
			double f = (double) sum / n;
			sumSqrs += f * f;
		}
		result[0]= (1.0 - sumSqrs);
		result[1] = sums.size();
		return result;

	}
	private double[] getMeanHeterozygosity() {
		double[] result = new double[2];
		double sumH = 0;
		double nUniqueAlleles = 0;
		//For each locus, sum h and the population of allele types.
		for (int position = 0; position < pool.size(); position++) {
			double [] h = getHeterozygosity(position);
			nUniqueAlleles += h[1];
			sumH += h[0];
		}
		// return average H
		result[0] = sumH / pool.size();
		result[1] = nUniqueAlleles;
		return result;
	}

	private static int maxX;
	private static int maxY;
	private static GeneticStatistics[][] map;
	private static int nLoci;
	
	public static void lazyInit(int width, int height, int nL) {
		// This will need to change to calculate Fst on larger populations??
		if (map != null)
			return;
		maxX = width;
		maxY = height;
		nLoci = nL;
		map = new GeneticStatistics[width][height];
		clear();
	}

	public static void recordAllele(int x, int y,int locus, long allele) {
		map[x][y].recordAllele(locus, allele);
	}
	
	public static double[] getHeterozygosity(int ix,int iy){
		return map[ix][iy].getMeanHeterozygosity();
	}

	public static void clear() {
		for (int x=0;x<maxX;x++)
			for (int y=0;y<maxY;y++)
				map[x][y] = new GeneticStatistics(nLoci);		
	}

}
