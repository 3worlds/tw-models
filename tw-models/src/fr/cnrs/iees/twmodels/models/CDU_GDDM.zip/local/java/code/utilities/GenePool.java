package code.utilities;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author ian
 *
 */
public class GenePool {
	private final List<List<Integer>> pool;
	private final List<Map<Integer, Integer>> alleleSums;

	public GenePool(int nLoci) {
		this.pool = new ArrayList<>();
		alleleSums = new ArrayList<>();
		for (int locus = 0; locus < nLoci; locus++) {
			pool.add(new ArrayList<Integer>());
			alleleSums.add(new HashMap<Integer, Integer>());
		}

	}

	public void recordAllele(int locus, int allele) {
		List<Integer> alleleValues = pool.get(locus);
		alleleValues.add(allele);
		Map<Integer, Integer> sums = alleleSums.get(locus);
		Integer sum = 0;
		if (sums.containsKey(allele))
			sum = sums.get(allele);
		sum++;
		sums.put(allele, sum);
	}

	public double[] getHeterozygosity(int locus) {
		double[] result = new double[2];
		List<Integer> alleleValues = pool.get(locus);
		double n = alleleValues.size();
		Map<Integer, Integer> sums = alleleSums.get(locus);
		double sumSqrs = 0;
		double maxSum = 0;
		// The most frequent allele
		int mfa = -1;
		for (Map.Entry<Integer, Integer> entry : sums.entrySet()) {
			Integer sum = entry.getValue();
			if (sum > maxSum) {
				maxSum = sum;
				mfa = entry.getKey();
			}
			double f = (double) sum / n;
			sumSqrs += f * f;
		}
		result[0] = (1.0 - sumSqrs);
//		result[1] = sums.size();
		result[1] = mfa;
		return result;

	}

	public double[] getMeanHeterozygosity() {
		double[] result = new double[2];
		double sumH = 0;
		double mfa = 0.0;
		// For each locus, sum h and the population of allele types.
		for (int locus = 0; locus < pool.size(); locus++) {
			double[] h = getHeterozygosity(locus);
			if (locus == 0)
				mfa += h[1];
			sumH += h[0];
		}
		// return average H
		result[0] = sumH / pool.size();
		result[1] = mfa;
		return result;
	}

}
