package code.utilities;

import static fr.cnrs.iees.uit.space.Distance.euclidianDistance;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Random;

import au.edu.anu.rscs.aot.collections.tables.DoubleTable;
import au.edu.anu.rscs.aot.collections.tables.IntTable;
import code.sys1.generated.Birth.OtherDrv;
import fr.ens.biologie.generic.utils.Tuple;

public class DispersalUtil {
	private DispersalUtil() {
	}
	
	public static final int disp_uninformed = 1;
	public static final int disp_informed = 3;

	private static Tuple<Double, Double, Double> getLocation(DoubleTable habitat, IntTable n, double cellSize,
			boolean ignoreOverPopulation, double k, double x, double y, Random rnd, double meanDistance, int method) {
		double x1;
		double y1;
		switch (method) {
		case 0: {// kernel
			double direction = rnd.nextDouble() * (2 * Math.PI);
			double distance = rnd.nextDouble() * meanDistance * 2.0;
			x1 = x + distance * Math.cos(direction);
			y1 = y + distance * Math.sin(direction);
			break;
		}
		case 1: {
			if (rnd.nextBoolean())
				x1 = x + rnd.nextDouble() * meanDistance * 2.0;
			else
				x1 = x - rnd.nextDouble() * meanDistance * 2.0;
			if (rnd.nextBoolean())
				y1 = y + rnd.nextDouble() * meanDistance * 2.0;
			else
				y1 = y - rnd.nextDouble() * meanDistance * 2.0;
			double deltaDistance = euclidianDistance(x, y, x1, y1);
			while (deltaDistance > meanDistance * 2.0) {
				if (rnd.nextBoolean())
					x1 = x + rnd.nextDouble() * meanDistance * 2.0;
				else
					x1 = x - rnd.nextDouble() * meanDistance * 2.0;
				if (rnd.nextBoolean())
					y1 = y + rnd.nextDouble() * meanDistance * 2.0;
				else
					y1 = y - rnd.nextDouble() * meanDistance * 2.0;
				deltaDistance = euclidianDistance(x, y, x1, y1);
			}
			break;

		}
		case 2: {
			if (rnd.nextBoolean())
				x1 = x + rnd.nextDouble() * meanDistance * 2.0;
			else
				x1 = x - rnd.nextDouble() * meanDistance * 2.0;
			if (rnd.nextBoolean())
				y1 = y + rnd.nextDouble() * meanDistance * 2.0;
			else
				y1 = y - rnd.nextDouble() * meanDistance * 2.0;
			break;
		}
		default: {// 3) -ve exponential
			double distance = -(meanDistance) * Math.log(1 - rnd.nextDouble());
			double direction = rnd.nextDouble() * (2 * Math.PI);
			x1 = x + distance * Math.cos(direction);
			y1 = y + distance * Math.sin(direction);
		}
		}// end switch
		int w = habitat.size(0);
		int h = habitat.size(1);

		int ix = (int) (x1 / cellSize);
		ix = ix % w;
		if (ix < 0)
			ix += w;
		int iy = (int) (y1 / cellSize);
		iy = iy % h;
		if (iy < 0)
			iy += h;

		int pop = n.getByInt(ix, iy);
		double hab = habitat.getByInt(ix, iy);
		double cc = hab * k;
		double xss = pop - cc;
		double weighting = hab+ rnd.nextDouble() * 0.1;
		if (!ignoreOverPopulation && xss>0)
			weighting -= 1.0;
		return new Tuple<Double, Double, Double>(x1, y1, weighting);
	}

	public static void disperse(OtherDrv otherDrv, DoubleTable habitat, IntTable n, double cellSize,
			boolean ignoreOverPopulation, double k, double x, double y, Random rnd, double meanDistance, int nTrials,
			int method) {
		if (nTrials == 1) {
			Tuple<Double, Double, Double> location = getLocation(habitat, n, cellSize, ignoreOverPopulation, k, x, y,
					rnd, meanDistance, method);
			otherDrv.x = location.getFirst();
			otherDrv.y = location.getSecond();
		} else {
			List<Tuple<Double, Double, Double>> trials = new ArrayList<>();
			for (int tr = 0; tr < nTrials; tr++)
				trials.add(getLocation(habitat, n, cellSize, ignoreOverPopulation, k, x, y, rnd, meanDistance, method));
			trials.sort(new Comparator<Tuple<Double, Double, Double>>() {

				@Override
				public int compare(Tuple<Double, Double, Double> o1, Tuple<Double, Double, Double> o2) {
					return o1.getThird().compareTo(o2.getThird());
				}
			});
			Tuple<Double, Double, Double> location = trials.get(trials.size() - 1);
			otherDrv.x = location.getFirst();
			otherDrv.y = location.getSecond();
		}
	}

}
