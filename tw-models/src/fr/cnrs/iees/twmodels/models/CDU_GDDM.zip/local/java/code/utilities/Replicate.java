package code.utilities;

import au.edu.anu.rscs.aot.collections.tables.IntTable;

public class Replicate {
	private  int maxX;
	private  int maxY;
	private  GenePool[][] map;
	private  int[][] sampleSize;
	private  int nLoci;
	private  GenePool totalPool;
	
	public Replicate (int maxX, int maxY, int nLoci) {
		this.maxX = maxX;
		this.maxY = maxY;
		this.nLoci=nLoci;
		map = new GenePool[maxX][maxY];
		sampleSize = new int[maxX][maxY];
		clear();
	}
	
	public  void clear() {
		totalPool = new GenePool(nLoci);
		for (int x=0;x<maxX;x++)
			for (int y=0;y<maxY;y++) {
				map[x][y] = new GenePool(nLoci);	
				sampleSize[x][y]=0;
			}
	}
	private  void recordAllele(int x, int y,int locus, int allele) {
		totalPool.recordAllele(locus, allele);
		map[x][y].recordAllele(locus, allele);
	}
	
	public  double[] getHeterozygosity(int x,int y){
		return map[x][y].getMeanHeterozygosity();
	}
	
	public  double[] getHt() {
		return totalPool.getMeanHeterozygosity();
	}
	
	public  int getSampleSize(int ix, int iy) {
		return sampleSize[ix][iy];
	}
	public  void recordAlleles(int x, int y, IntTable alleles, int mDNA) {
		sampleSize[x][y]++;
		map[x][y].recordmDNA(mDNA);
		int mxLoci = alleles.size(0);
		int mxPloidy = alleles.size(1);
		for (int locus = 0; locus < mxLoci; locus++)
			for (int ploidy = 0; ploidy < mxPloidy; ploidy++) {
				recordAllele(x, y, locus, alleles.getByInt(locus, ploidy));
			}	
	}

	public int getMostFrequentmDNA(int x, int y) {
		return map[x][y].getmDNAmfa();
	}

}
