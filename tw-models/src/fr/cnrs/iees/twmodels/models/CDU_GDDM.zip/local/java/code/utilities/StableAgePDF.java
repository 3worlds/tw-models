package code.utilities;

import java.util.Random;

public class StableAgePDF {
	
	private static double[] pdf;
	public static void initialise(int nJAC, int nAAC, double jdr, double adr) {
		pdf = new double [2+nJAC+nAAC+2];
		pdf[0] = 1.0;
		double ps = 1 - jdr;
		for (int i = 0; i < nJAC; i++)
			pdf[i + 1] = ps;
		ps = 1 - adr;
		for (int i = 0; i<nAAC;i++)
			pdf[i+1+nJAC]= ps;
		pdf[pdf.length-1]=1.0;
		double sum = 0.0;
		for (int i = 0;i<pdf.length;i++)
			sum+=pdf[i];
		for (int i = 0;i<pdf.length;i++)
			pdf[i]=pdf[i]/sum;
		for (int i = 1;i<pdf.length;i++)
			pdf[i]=pdf[i]+pdf[i-1];

		pdf[pdf.length-1]=1.0;

	}
	public static int getAge (Random rng) {
		double p = rng.nextDouble();
		for (int i=0;i<pdf.length;i++)
			if (p<pdf[i])
				return i;
		return pdf.length;
	}

	public static void main(String[] args) {
		int nJuvenileAgeClasses = 1;
		int nAdultAgeClasses = 1;
		double juvenileDeathRate = 0.75;
		double adultDeathRate = 0.2;
		double[] x = new double[2 + nJuvenileAgeClasses + nAdultAgeClasses];
		x[0] = 1.0;
		double ps = 1 - juvenileDeathRate;
		for (int i = 0; i < nJuvenileAgeClasses; i++)
			x[i + 1] = ps;
		ps = 1 - adultDeathRate;
		for (int i = 0; i<nAdultAgeClasses;i++)
			x[i+1+nJuvenileAgeClasses]= ps;
		x[x.length-1]=1.0;
		double sum = 0.0;
		for (int i = 0;i<x.length;i++)
			sum+=x[i];
		for (int i = 0;i<x.length;i++)
			x[i]=x[i]/sum;
		for (int i = 1;i<x.length;i++)
			x[i]=x[i]+x[i-1];

		x[x.length-1]=1.0;

		for (int i = 0; i<x.length;i++)
			System.out.println(x[i]);
	}

}
