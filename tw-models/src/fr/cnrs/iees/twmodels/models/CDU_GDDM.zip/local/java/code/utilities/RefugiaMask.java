package code.utilities;

import java.util.Random;

import au.edu.anu.rscs.aot.collections.tables.BooleanTable;

public class RefugiaMask {
	private RefugiaMask() {
	};
	public final static int ro_static = 0;
	public final static int ro_dynamic = 1;
	
	public final static int rco_none = 0;
	public final static int rco_low = 1;
	public final static int rco_high = 2;

	


	public static void buildMask(BooleanTable refugia, int opt, boolean clumped, Random rng) {
		if (opt == 0)
			return;
		int maxx = refugia.size(0);
		int maxy = refugia.size(1);
		if (!clumped) {
			// fraction of the landscape to mask
			double fraction = 0.05;
			if (opt == 2)
				fraction = 0.2;
			for (int x = 0; x < maxx; x++)
				for (int y = 0; y < maxy; y++)
					if (rng.nextDouble()<fraction)
					refugia.setByInt(true, x, y);
			return;
		}
		// clumped
		int size = 22; // dim of refugia
		if (opt == 1) {
			int offsetX = rng.nextInt(maxx);
			int offsetY = rng.nextInt(maxy);

			// one square in random position
			int ox = rng.nextInt(maxx);
			int oy = rng.nextInt(maxy);
			for (int x = 0; x < size; x++)
				for (int y = 0; y < size; y++) {
					int xWrap = (x + ox+offsetX) % maxx;
					int yWrap = (y + oy+offsetY) % maxy;
					refugia.setByInt(true, xWrap, yWrap);
				}
			return;
		}
		// opt ==2: four randomly placed non-overlaping squares
		// for each quadrant
		int offsetX = rng.nextInt(maxx);
		int offsetY = rng.nextInt(maxy);
		for (int xq = 0;xq<2;xq++)
			for (int yq = 0; yq<2;yq++) {
				int ox = xq * (maxx / 2) + rng.nextInt(maxx / 4);
				int oy = yq * (maxy / 2) + rng.nextInt(maxy / 4);
				for (int x = 0; x < size; x++)
					for (int y = 0; y < size; y++) {
						int xWrap = (x + ox+offsetX) % maxx;
						int yWrap = (y + oy+offsetY) % maxy;
						refugia.setByInt(true, xWrap, yWrap);
					}
			}
	};

}
