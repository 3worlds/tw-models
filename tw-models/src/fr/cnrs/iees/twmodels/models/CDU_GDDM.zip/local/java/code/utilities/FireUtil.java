package code.utilities;

import java.util.Random;

import au.edu.anu.rscs.aot.collections.tables.BooleanTable;
import au.edu.anu.rscs.aot.collections.tables.DoubleTable;
import au.edu.anu.rscs.aot.collections.tables.IntTable;
import code.sys1.generated.UpdateLayers.FocalDec;
import code.sys1.generated.UpdateLayers.FocalDrv;

public class FireUtil {
	private FireUtil() {
	}

	public static void updateLayers1(double time, FocalDrv focalDrv, FocalDec focalDec, IntTable fireCount,
			boolean fireLarge, double fireProb, double fireEarlyProb, double refugiaStrength, BooleanTable refugia,
			IntTable fireHistory, DoubleTable fireEarlyHabitatFunc, DoubleTable fireLateHabitatFunc, Random random) {
		int z = (int) (time % focalDrv.fireHistory.size(2));
		int w = focalDec.fireType.size(0);
		int h = focalDec.fireType.size(1);
		// convert footprint from meters to number of cells
		int xFootPrint = 5;
		int yFootPrint = 5;
		if (fireLarge) {
			xFootPrint = 30;
			yFootPrint = 30;
		}
		//focalDec.fireType.fillWith(0);
		focalDrv.fireCount.copy(fireCount);
		for (int x = 0; x < w; x++)
			for (int y = 0; y < h; y++) {
				focalDrv.fireHistory.setByInt(0, x, y, z);
			}

		double lw = w;
		double lh = h;
		double fireArea = xFootPrint * yFootPrint;
		double tmp;
		tmp = ((Math.sqrt(fireProb) * lw) / (double) xFootPrint);
		int xSlots = (int) tmp;
		if (Math.floor(tmp) < tmp)
			xSlots++;
		if (xSlots * xFootPrint >= lw)
			xSlots--;
		tmp = ((Math.sqrt(fireProb) * lh) / (double) yFootPrint);
		int ySlots = (int) tmp;
		if (Math.floor(tmp) < tmp)
			ySlots++;
		if (ySlots * xFootPrint >= lw)
			ySlots--;
		double slotw = lw / xSlots;
		double sloth = lh / ySlots;
		double slotArea = slotw * sloth;
		// Transform probability of fire in slot i to account for area lost to fire
		// margins
		double returnInterval = slotArea / fireArea * fireProb;
		double xJiggle = slotw - xFootPrint - 1;
		double yJiggle = sloth - yFootPrint - 1;
		// Much of the above could be done in a secondary init method
		double xDisplacement = random.nextDouble() * lw;
		double yDisplacement = random.nextDouble() * lh;
		for (int xSlot = 0; xSlot < xSlots; xSlot++)
			for (int ySlot = 0; ySlot < ySlots; ySlot++) {
				if (random.nextDouble() < returnInterval) {
					boolean enterRef = random.nextDouble() > refugiaStrength;
					int xFireStart = (int) ((xSlot * slotw + random.nextDouble() * xJiggle) + xDisplacement);
					int yFireStart = (int) ((ySlot * sloth + random.nextDouble() * yJiggle) + yDisplacement);
					int ft;
					if (random.nextDouble() < fireEarlyProb)
						ft = 1;// early season fire
					else
						ft = 2;// late season fire

					for (int i = 0; i < xFootPrint; i++)
						for (int j = 0; j < yFootPrint; j++) {
							// torus
							int ix = (xFireStart + i) % w;
							int iy = (yFireStart + j) % h;
							boolean burn = false;
							if (!refugia.getByInt(ix, iy))
								burn = true;
							else if (enterRef)
								burn = true;
							if (burn) {
								focalDec.fireBurntFract++;
								if (ft == 1)
									focalDec.fireEarlyFract++;
								else
									focalDec.fireLateFract++;
								focalDec.fireType.setByInt(ft, ix, iy);
								int c = fireCount.getByInt(ix, iy);
								focalDrv.fireCount.setByInt(c + 1, ix, iy);
								focalDrv.fireHistory.setByInt(ft, ix, iy, z);
							}
						}
				}
			}
		for (int x = 0; x < w; x++)
			for (int y = 0; y < h; y++) {
				double c = focalDrv.fireCount.getByInt(x, y);
				focalDec.fireFrequency.setByInt(c / time, x, y);
				int[] history = new int[fireHistory.size(2)];
				int now = (int) (time % history.length);
				for (int i = now; i < history.length; i++) {
					int f = focalDrv.fireHistory.getByInt(x, y, i);
					history[i - now] = f;
				}
				for (int i = 0; i < now; i++) {
					int f = focalDrv.fireHistory.getByInt(x, y, i);
					history[i + history.length - now] = f;
				}
				double hab = 1.0;
				double e = 1.0;
				double l = 1.0;
				for (int year = history.length - 1; year >= 0; year--) {
					if (history[year] == 2)
						hab = fireLateHabitatFunc.getByInt(year);
					if (history[year] == 1)
						hab = fireEarlyHabitatFunc.getByInt(year);
				}
				focalDec.habitat.setByInt(hab, x, y);
			}
		focalDec.fireBurntFract = focalDec.fireBurntFract / (w * h);
		focalDec.fireEarlyFract = focalDec.fireEarlyFract / (w * h);
		focalDec.fireLateFract = focalDec.fireLateFract / (w * h);

	}

	public static void updateLayers2(double time, FocalDrv focalDrv, FocalDec focalDec, IntTable fireCount, boolean fireLarge,
			double fireProb, double fireEarlyProb, double refugiaStrength, BooleanTable refugia, IntTable fireHistory,
			DoubleTable fireEarlyHabitatFunc, DoubleTable fireLateHabitatFunc, Random random) {
		int z = (int) (time % focalDrv.fireHistory.size(2));
		int w = fireCount.size(0);
		int h = fireCount.size(1);
		// convert footprint from meters to number of cells
		int xFootPrint = 5;
		int yFootPrint = 5;
		if (fireLarge) {
			xFootPrint = 30;
			yFootPrint = 30;
		}
	
//		focalDrv.fireCount.copy(fireCount);
//		focalDrv.fireHistory.copy(fireHistory);
		for (int x = 0; x < w; x++)
			for (int y = 0; y < h; y++) {
				focalDrv.fireHistory.setByInt(0, x, y, z);
			}

		double lw = w;
		double lh = h;
		double fireArea = xFootPrint * yFootPrint;
		int xSlots = w/xFootPrint;
		int ySlots = h/yFootPrint;
		double xDisplacement = random.nextDouble() * lw;
		double yDisplacement = random.nextDouble() * lh;
		for (int xSlot = 0; xSlot < xSlots; xSlot++)
			for (int ySlot = 0; ySlot < ySlots; ySlot++) {
				if (random.nextDouble() < fireProb) {
					boolean enterRef = random.nextDouble() > refugiaStrength;
					int xFireStart = (int) (xSlot * xFootPrint  + xDisplacement);
					int yFireStart = (int) (ySlot * xFootPrint + yDisplacement);
					int ft;
					if (random.nextDouble() < fireEarlyProb)
						ft = 1;// early season fire
					else
						ft = 2;// late season fire

					for (int i = 0; i < xFootPrint; i++)
						for (int j = 0; j < yFootPrint; j++) {
							// torus
							int ix = (xFireStart + i) % w;
							int iy = (yFireStart + j) % h;
							boolean burn = false;
							if (!refugia.getByInt(ix, iy))
								burn = true;
							else if (enterRef)
								burn = true;
							if (burn) {
								focalDec.fireBurntFract++;
								if (ft == 1)
									focalDec.fireEarlyFract++;
								else
									focalDec.fireLateFract++;
								focalDec.fireType.setByInt(ft, ix, iy);
								int c = fireCount.getByInt(ix, iy);
								focalDrv.fireCount.setByInt(c + 1, ix, iy);
								focalDrv.fireHistory.setByInt(ft, ix, iy, z);
							}
						}
				}
			}
		for (int x = 0; x < w; x++)
			for (int y = 0; y < h; y++) {
				double c = focalDrv.fireCount.getByInt(x, y);
				focalDec.fireFrequency.setByInt(c / time, x, y);
				int[] history = new int[fireHistory.size(2)];
				
				int now = (int) (time % history.length);
				for (int i = now; i < history.length; i++) {
					int f = focalDrv.fireHistory.getByInt(x, y, i);
					history[i - now] = f;
				}
				for (int i = 0; i < now; i++) {
					int f = focalDrv.fireHistory.getByInt(x, y, i);
					history[i + history.length - now] = f;
				}
				double hab = 1.0;
				double e = 1.0;
				double l = 1.0;
				for (int year = history.length - 1; year >= 0; year--) {
					if (history[year] == 2)
						hab = fireLateHabitatFunc.getByInt(year);
					if (history[year] == 1)
						hab = fireEarlyHabitatFunc.getByInt(year);
				}
				focalDec.habitat.setByInt(hab, x, y);
			}
		focalDec.fireBurntFract = focalDec.fireBurntFract / (w * h);
		focalDec.fireEarlyFract = focalDec.fireEarlyFract / (w * h);
		focalDec.fireLateFract = focalDec.fireLateFract / (w * h);

		
	};

}
