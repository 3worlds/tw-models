package code.utilities;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import au.edu.anu.rscs.aot.collections.tables.LongTable;

/**
 * @author ian
 * 
 * TODO Fst
 *
 */
public class GDDMUtil {

	private static int maxX;
	private static int maxY;
	private static GenePool[][] map;
	private static int[][] sampleSize;
	private static int nLoci;
	private static GenePool totalPool;
	
	private GDDMUtil () {};
	
	public static void lazyInit(int width, int height, int nL) {
		if (map != null)
			return;
		maxX = width;
		maxY = height;
		nLoci = nL;
		map = new GenePool[width][height];
		sampleSize = new int[width][height];
		clear();
	}

	private static void recordAllele(int x, int y,int locus, long allele) {
		totalPool.recordAllele(locus, allele);
		map[x][y].recordAllele(locus, allele);
	}
	
	public static double[] getHeterozygosity(int x,int y){
		return map[x][y].getMeanHeterozygosity();
	}
	
	public static double[] getHt() {
		return totalPool.getMeanHeterozygosity();
	}
	
	public static int getSampleSize(int ix, int iy) {
		return sampleSize[ix][iy];
	}
	
	public static void clear() {
		totalPool = new GenePool(nLoci);
		for (int x=0;x<maxX;x++)
			for (int y=0;y<maxY;y++) {
				map[x][y] = new GenePool(nLoci);	
				sampleSize[x][y]=0;
			}
	}

	private static List<List<Long>> alleleBag;
	public static void lazyAlleleInit(int nLoci) {
		if (alleleBag!=null)
			return;
		alleleBag = new ArrayList<>();
		for (int i=0; i<nLoci;i++) {
			List<Long> lst = new ArrayList<>();
			alleleBag.add(lst);
			for (int j = 0; j<10;j++) {
				long allele = j+i*10;
				lst.add(allele);
			}		
		}	
	}

	public static Long getRandomAllele(Random random, int locus) {
		Long result;
		List<Long> bag = alleleBag.get(locus);
		result = bag.get(random.nextInt(bag.size()));
		return result;
	}
// Real one
	public static void recordAlleles(int x, int y, LongTable alleles) {
		sampleSize[x][y]++;
		int mxLoci = alleles.size(0);
		int mxPloidy = alleles.size(1);
		for (int locus = 0; locus < mxLoci; locus++)
			for (int ploidy = 0; ploidy < mxPloidy; ploidy++) {
				recordAllele(x, y, locus, alleles.getByInt(locus, ploidy));
			}	
	}
}
