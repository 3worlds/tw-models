package code.utilities;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import au.edu.anu.rscs.aot.collections.tables.IntTable;

/**
 * @author ian
 * 
 *         TODO Fst
 *
 */
public class GDDMUtil {

	private static Map<Long, Replicate> replicates = new HashMap<>();
	private static List<List<Integer>> alleleBag;

	private GDDMUtil() {
	};

	public static Replicate lazyInit(int width, int height, int nL) {
		long key = Thread.currentThread().getId();
		Replicate result = replicates.get(key);
		if (result!=null)
			return result;
		result = new Replicate(width, height, nL);
		replicates.put(key, result);
		return result;
	}


	public static Replicate getReplicate() {
		long key = Thread.currentThread().getId();
		return replicates.get(key);
	};

	public static void clear() {
		replicates.clear();
	}



	public static void lazyAlleleInit(int nLoci) {
		if (alleleBag != null)
			return;
		alleleBag = new ArrayList<>();
		for (int i = 0; i < nLoci; i++) {
			List<Integer> lst = new ArrayList<>();
			alleleBag.add(lst);
			for (int j = 0; j < 10; j++) {
				int allele = j + i * 10;
				lst.add(allele);
			}
		}
	}

	public static int getRandomAllele(Random random, int locus) {
		int result;
		List<Integer> bag = alleleBag.get(locus);
		result = bag.get(random.nextInt(bag.size()));
		return result;
	}

}
