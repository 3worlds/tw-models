package code.sys1;

import static java.lang.Math.PI;
import static java.lang.Math.pow;

import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.MaxCountExceededException;
import org.apache.commons.math3.ode.FirstOrderDifferentialEquations;

public class ResproutEquations implements FirstOrderDifferentialEquations {
	
	private double a,b,reservesMax,p,r,q,s,n,f,e,m,mL;
	
	public ResproutEquations(double a,double b,double reservesMax,double p,double r,double q,double s,double n,double f,double e,double m,double mL) {
		super();
		this.a = a;
		this.b = b;
		this.p = p;
		this.r = r;
		this.s = s;
		this.q = q;
		this.n = n;
		this.m = m;
		this.e = e;
		this.f = f;
		this.reservesMax = reservesMax;
		this.mL = mL;
	}

	@Override
	public int getDimension() {
		return 4;
	}

	@Override
	public void computeDerivatives(double t, double[] y, double[] yDot)
			throws MaxCountExceededException, DimensionMismatchException {
		double bmL = y[0];
		double bmS = y[1];
		double bmR = y[2];
		double reserves = y[3];
		
		// growth = photosynthesis + translocation from reserves
		double G = a*bmL + b*reserves;
		// maximal reserve storage
		double bplim = 1 - (reserves/reservesMax)*(bmR+bmS);
		// increase in reserve biomass TODO:integration
		double dResdt = p*bplim*G - b*reserves;
		// correction term for root allocation coef
		double alpha = 1 - p*bplim/(1-p);
		// increase in root biomass TODO: integration + check: use of alpha ?
		double dRdt = r*alpha*G - q*bmR;
		// aboveground growth
		double GA = s*alpha*G;
		// architecture constraint
		double beta = n*mL*pow(8*f*f/(PI*m),1.0/3)/e;			
		// increase in stem biomass TODO:integration
		double beta3 = pow(beta,3);
		double dSdt = s * 3*bmL*bmL/(beta3+3*bmL*bmL) *GA - q*bmS;
		// increase in leaf biomass TODO:integration
		double dLdt = s * beta3/(beta3+3*bmL*bmL) * GA;
		
		yDot[0] = dLdt;
		yDot[1] = dSdt;
		yDot[2] = dRdt;
		yDot[3] = dResdt;
	}

}
