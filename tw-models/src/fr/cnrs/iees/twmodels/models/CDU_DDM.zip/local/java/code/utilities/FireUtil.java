package code.utilities;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import au.edu.anu.rscs.aot.collections.tables.BooleanTable;
import au.edu.anu.rscs.aot.collections.tables.DoubleTable;
import au.edu.anu.rscs.aot.collections.tables.IntTable;
import code.sys1.generated.UpdateLayers.FocalDec;
import code.sys1.generated.UpdateLayers.FocalDrv;

/**
 * @author ian
 *
 */
public class FireUtil {
	private FireUtil() {
	}

	public static final int FIRE_NONE = 0;
	public static final int FIRE_EARLY = 1;
	public static final int FIRE_LATE = 2;

	public static int fixedSquares0(double time, FocalDrv focalDrv, FocalDec focalDec, IntTable fireFixedPattern,
			IntTable fireCount, int fireSize, double fireProb, double fireEarlyProb, double refugiaStrength,
			BooleanTable refugia, IntTable fireHistory, DoubleTable fireEarlyHabitatFunc,
			DoubleTable fireLateHabitatFunc, Random random) {
		int z = (int) (time % focalDrv.fireHistory.size(2));
		int w = fireCount.size(0);
		int h = fireCount.size(1);
		int result = 0;
		if (!focalDrv.fireFixedPatternInitialised) {
			focalDrv.fireFixedPatternInitialised = true;
			focalDrv.fireFixedPattern.fillWith(0);
			// NB foot print is in cell size units (nominally 100 meters)
			int xFootPrint = fireSize;
			int yFootPrint = fireSize;
			double lw = w;
			double lh = h;
			int slotArea = xFootPrint*yFootPrint;
			int xSlots = w / xFootPrint;
			int ySlots = h / yFootPrint;
			if (xSlots * xFootPrint < w) {
				xSlots++;
				ySlots++;
			}
			double slotLandscapeArea = xSlots*ySlots*slotArea;
			double ratio = (lw*lh)/slotLandscapeArea;
			double returnInterval = ratio*fireProb;

			double xDisplacement = random.nextDouble() * lw;
			double yDisplacement = random.nextDouble() * lh;
			for (int xSlot = 0; xSlot < xSlots; xSlot++)
				for (int ySlot = 0; ySlot < ySlots; ySlot++) {
					if (random.nextDouble() < returnInterval) {
						boolean enterRef = random.nextDouble() > refugiaStrength;
						result++;
						int xFireStart = (int) (xSlot * xFootPrint + xDisplacement);
						int yFireStart = (int) (ySlot * xFootPrint + yDisplacement);
						int ft;
						if (random.nextDouble() < fireEarlyProb)
							ft = FIRE_EARLY;// designated early season fire
						else
							ft = FIRE_LATE;// designated late season fire

						for (int i = 0; i < xFootPrint; i++)
							for (int j = 0; j < yFootPrint; j++) {
								// torus
								int ix = (xFireStart + i) % w;
								int iy = (yFireStart + j) % h;
								boolean burn = false;
								if (!refugia.getByInt(ix, iy))
									burn = true;
								else if (enterRef)
									burn = true;
								if (burn) {
									focalDrv.fireFixedPattern.setByInt(ft, ix, iy);
									fireFixedPattern.setByInt(ft, ix, iy);
								}
							}
					}
				}
		}
		for (int x = 0; x < w; x++)
			for (int y = 0; y < h; y++) {
				int ft = fireFixedPattern.getByInt(x, y);
				focalDec.fireType.setByInt(ft, x, y);
				focalDrv.fireHistory.setByInt(ft, x, y, z);
				if (ft > 0) {
					focalDrv.fireCount.setByInt(focalDrv.fireCount.getByInt(x, y) + 1, x, y);
					focalDec.fireBurntFract++;
					if (ft == FIRE_EARLY)
						focalDec.fireEarlyFract++;
					else
						focalDec.fireLateFract++;
				}
				double c = focalDrv.fireCount.getByInt(x, y);
				focalDec.fireFrequency.setByInt(c / time, x, y);
				int[] history = new int[fireHistory.size(2)];

				int now = (int) (time % history.length);
				for (int i = now; i < history.length; i++) {
					int f = focalDrv.fireHistory.getByInt(x, y, i);
					history[i - now] = f;
				}
				for (int i = 0; i < now; i++) {
					int f = focalDrv.fireHistory.getByInt(x, y, i);
					history[i + history.length - now] = f;
				}
				double hab = 1.0;
				for (int year = history.length - 1; year >= 0; year--) {
					if (history[year] == FIRE_LATE)
						hab = fireLateHabitatFunc.getByInt(year);
					if (history[year] == FIRE_EARLY)
						hab = fireEarlyHabitatFunc.getByInt(year);
				}
				focalDec.habitat.setByInt(hab, x, y);
			}
		focalDec.fireBurntFract = focalDec.fireBurntFract / (w * h);
		focalDec.fireEarlyFract = focalDec.fireEarlyFract / (w * h);
		focalDec.fireLateFract = focalDec.fireLateFract / (w * h);
		return result;

	};

	public static int squareNonContiguous1(double time, FocalDrv focalDrv, FocalDec focalDec, IntTable fireCount,
			int fireSize, double fireProb, double fireEarlyProb, double refugiaStrength, BooleanTable refugia,
			IntTable fireHistory, DoubleTable fireEarlyHabitatFunc, DoubleTable fireLateHabitatFunc, Random random) {
		
		int z = (int) (time % focalDrv.fireHistory.size(2));
		int w = focalDec.fireType.size(0);
		int h = focalDec.fireType.size(1);
		// NB foot print is in cell size units (nominally 100 meters)
		int xFootPrint = fireSize;
		int yFootPrint = fireSize;
		// init with 'no fire'
		for (int x = 0; x < w; x++)
			for (int y = 0; y < h; y++) {
				focalDrv.fireHistory.setByInt(0, x, y, z);
			}

		double lw = w;
		double lh = h;
		double fireArea = xFootPrint * yFootPrint;
		double tmp;
		tmp = ((Math.sqrt(fireProb) * lw) / (double) xFootPrint);
		int xSlots = (int) tmp;
		if (Math.floor(tmp) < tmp)
			xSlots++;
		if (xSlots * xFootPrint >= lw)
			xSlots--;
		tmp = ((Math.sqrt(fireProb) * lh) / (double) yFootPrint);
		int ySlots = (int) tmp;
		if (Math.floor(tmp) < tmp)
			ySlots++;
		if (ySlots * xFootPrint >= lw)
			ySlots--;
		double slotw = lw / xSlots;
		double sloth = lh / ySlots;
		double slotArea = slotw * sloth;
		// Transform probability of fire in slot i to account for area lost to fire
		// margins
		double ratio = slotArea / fireArea;
		
		double returnInterval = ratio * fireProb;
		double xJiggle = slotw - xFootPrint - 1;
		double yJiggle = sloth - yFootPrint - 1;
		// Much of the above could be done in a secondary init method
		double xDisplacement = random.nextDouble() * lw;
		double yDisplacement = random.nextDouble() * lh;
		int result = 0;
		for (int xSlot = 0; xSlot < xSlots; xSlot++)
			for (int ySlot = 0; ySlot < ySlots; ySlot++) {
				if (random.nextDouble() < returnInterval) {
					result++;
					boolean enterRef = random.nextDouble() > refugiaStrength;
					int xFireStart = (int) ((xSlot * slotw + random.nextDouble() * xJiggle) + xDisplacement);
					int yFireStart = (int) ((ySlot * sloth + random.nextDouble() * yJiggle) + yDisplacement);
					int ft;
					if (random.nextDouble() < fireEarlyProb)
						ft = FIRE_EARLY;// designated early season fire
					else
						ft = FIRE_LATE;// designated late season fire

					for (int i = 0; i < xFootPrint; i++)
						for (int j = 0; j < yFootPrint; j++) {
							// torus
							int ix = (xFireStart + i) % w;
							int iy = (yFireStart + j) % h;
							boolean burn = false;
							if (!refugia.getByInt(ix, iy))
								burn = true;
							else if (enterRef)
								burn = true;
							if (burn) {
								focalDec.fireBurntFract++;
								if (ft == FIRE_EARLY)
									focalDec.fireEarlyFract++;
								else
									focalDec.fireLateFract++;
								focalDec.fireType.setByInt(ft, ix, iy);
								int c = fireCount.getByInt(ix, iy);
								focalDrv.fireCount.setByInt(c + 1, ix, iy);
								focalDrv.fireHistory.setByInt(ft, ix, iy, z);
							}
						}
				}
			}
		for (int x = 0; x < w; x++)
			for (int y = 0; y < h; y++) {
				double c = focalDrv.fireCount.getByInt(x, y);
				focalDec.fireFrequency.setByInt(c / time, x, y);
				int[] history = new int[fireHistory.size(2)];
				int now = (int) (time % history.length);
				for (int i = now; i < history.length; i++) {
					int f = focalDrv.fireHistory.getByInt(x, y, i);
					history[i - now] = f;
				}
				for (int i = 0; i < now; i++) {
					int f = focalDrv.fireHistory.getByInt(x, y, i);
					history[i + history.length - now] = f;
				}
				double hab = 1.0;
				for (int year = history.length - 1; year >= 0; year--) {
					if (history[year] == FIRE_LATE)
						hab = fireLateHabitatFunc.getByInt(year);
					if (history[year] == FIRE_EARLY)
						hab = fireEarlyHabitatFunc.getByInt(year);
				}
				focalDec.habitat.setByInt(hab, x, y);
			}
		focalDec.fireBurntFract = focalDec.fireBurntFract / (w * h);
		focalDec.fireEarlyFract = focalDec.fireEarlyFract / (w * h);
		focalDec.fireLateFract = focalDec.fireLateFract / (w * h);
		return result;
	}

	public static int squareContiguous2(double time, FocalDrv focalDrv, FocalDec focalDec, IntTable fireCount,
			int fireSize, double fireProb, double fireEarlyProb, double refugiaStrength, BooleanTable refugia,
			IntTable fireHistory, DoubleTable fireEarlyHabitatFunc, DoubleTable fireLateHabitatFunc, Random random) {
		int z = (int) (time % focalDrv.fireHistory.size(2));
		int w = fireCount.size(0);
		int h = fireCount.size(1);
		// NB foot print is in cell size units (nominally 100 meters)
		int xFootPrint = fireSize;
		int yFootPrint = fireSize;
		// init with 'no fire'
		for (int x = 0; x < w; x++)
			for (int y = 0; y < h; y++) {
				focalDrv.fireHistory.setByInt(0, x, y, z);
			}

		double lw = w;
		double lh = h;
		int xSlots = w / xFootPrint;
		int ySlots = h / yFootPrint;
		int slotArea = xFootPrint*yFootPrint;
		if (xSlots * xFootPrint < w) {
			xSlots++;
			ySlots++;
		}
		double slotLandscapeArea = xSlots*ySlots*slotArea;
		double ratio = (lw*lh)/slotLandscapeArea;
		double returnInterval = ratio*fireProb;

		int result = 0;
		double xDisplacement = random.nextDouble() * lw;
		double yDisplacement = random.nextDouble() * lh;
		for (int xSlot = 0; xSlot < xSlots; xSlot++)
			for (int ySlot = 0; ySlot < ySlots; ySlot++) {
				if (random.nextDouble() < returnInterval) {
					result++;
					boolean enterRef = random.nextDouble() > refugiaStrength;
					int xFireStart = (int) (xSlot * xFootPrint + xDisplacement);
					int yFireStart = (int) (ySlot * xFootPrint + yDisplacement);
					int ft;
					if (random.nextDouble() < fireEarlyProb)
						ft = FIRE_EARLY;// designated early season fire
					else
						ft = FIRE_LATE;// designated late season fire

					for (int i = 0; i < xFootPrint; i++)
						for (int j = 0; j < yFootPrint; j++) {
							// torus
							int ix = (xFireStart + i) % w;
							int iy = (yFireStart + j) % h;
							boolean burn = false;
							if (!refugia.getByInt(ix, iy))
								burn = true;
							else if (enterRef)
								burn = true;
							if (burn) {
								focalDec.fireBurntFract++;
								if (ft == FIRE_EARLY)
									focalDec.fireEarlyFract++;
								else
									focalDec.fireLateFract++;
								focalDec.fireType.setByInt(ft, ix, iy);
								int c = fireCount.getByInt(ix, iy);
								focalDrv.fireCount.setByInt(c + 1, ix, iy);
								focalDrv.fireHistory.setByInt(ft, ix, iy, z);
							}
						}
				}
			}
		for (int x = 0; x < w; x++)
			for (int y = 0; y < h; y++) {
				double c = focalDrv.fireCount.getByInt(x, y);
				focalDec.fireFrequency.setByInt(c / time, x, y);
				int[] history = new int[fireHistory.size(2)];

				int now = (int) (time % history.length);
				for (int i = now; i < history.length; i++) {
					int f = focalDrv.fireHistory.getByInt(x, y, i);
					history[i - now] = f;
				}
				for (int i = 0; i < now; i++) {
					int f = focalDrv.fireHistory.getByInt(x, y, i);
					history[i + history.length - now] = f;
				}
				double hab = 1.0;
				for (int year = history.length - 1; year >= 0; year--) {
					if (history[year] == FIRE_LATE)
						hab = fireLateHabitatFunc.getByInt(year);
					if (history[year] == FIRE_EARLY)
						hab = fireEarlyHabitatFunc.getByInt(year);
				}
				focalDec.habitat.setByInt(hab, x, y);
			}
		focalDec.fireBurntFract = focalDec.fireBurntFract / (w * h);
		focalDec.fireEarlyFract = focalDec.fireEarlyFract / (w * h);
		focalDec.fireLateFract = focalDec.fireLateFract / (w * h);
		return result;
	}

	public static int contagion3(double time, FocalDrv focalDrv, FocalDec focalDec, IntTable fireCount, int fireSize,
			double fireProb, double fireEarlyProb, double refugiaStrength, BooleanTable refugia, IntTable fireHistory,
			DoubleTable fireEarlyHabitatFunc, DoubleTable fireLateHabitatFunc, Random random, double pContagiousSpread,
			int refugiaCoverageOption) {

		int z = (int) (time % focalDrv.fireHistory.size(2));
		int w = fireCount.size(0);
		int h = fireCount.size(1);
		// init with 'no fire'
		for (int x = 0; x < w; x++)
			for (int y = 0; y < h; y++) {
				focalDrv.fireHistory.setByInt(0, x, y, z);
			}

		int result = 0;
		Map<String, List<Integer>> unburntList = new HashMap<>();
		List<String> keys = new ArrayList<>();
		for (int x = 0; x < w; x++)
			for (int y = 0; y < h; y++) {
				List<Integer> l = new ArrayList<>();
				l.add(x);
				l.add(y);
				String key = x + "-" + y;
				keys.add(key);
				unburntList.put(key, l);
			}

		boolean[][] visited = new boolean[w][h];

		// NB Conflict.reduce quota by strength and area of refugia;
		double fract;
		switch (refugiaCoverageOption) {
		case 0: {
			fract = 0;
			break;
		}
		case 1: {
			fract = 0.05;
			break;
		}
		default: {
			fract = 0.2;
		}
		}
		int area = w*h;
		int refArea = (int) (area*fract*refugiaStrength);
		area = area - refArea;
		int quota = (int) (fireProb * area);

		int nBurnt = 0;
		while (nBurnt < quota) {
			double pSpread = 1.0;
			boolean enterRef = random.nextDouble() > refugiaStrength;
			int ft;
			if (random.nextDouble() < fireEarlyProb)
				ft = FIRE_EARLY;// designated early season fire
			else
				ft = FIRE_LATE;// designated late season fire
			// ignition
			List<Integer> firelineX = new ArrayList<>();
			List<Integer> firelineY = new ArrayList<>();

			int idx = random.nextInt(keys.size());
			String key = keys.get(idx);
			keys.remove(idx);

			List<Integer> l = unburntList.get(key);
			int x = l.get(0);
			int y = l.get(1);
			// check if refugia
			boolean burn = true;
			if (!enterRef && refugia.getByInt(x, y))
				burn = false;
			if (burn) {
				nBurnt++;
				burn(x, y, z, ft, focalDec, focalDrv, fireCount, time, fireEarlyHabitatFunc, fireLateHabitatFunc);
				firelineX.add(x);
				firelineY.add(y);
				visited[x][y] = true;
			}

			while (!firelineX.isEmpty() && nBurnt < quota) {
				pSpread = pSpread * pContagiousSpread;
				spreadFrom(firelineX, firelineY, visited, pSpread, random, w, h, enterRef, refugia);
				nBurnt += firelineX.size();
				for (int i = 0; i < firelineX.size(); i++) {
					x = firelineX.get(i);
					y = firelineY.get(i);
					key = x + "-" + y;
					keys.remove(key);
					burn(x, y, z, ft, focalDec, focalDrv, fireCount, time, fireEarlyHabitatFunc, fireLateHabitatFunc);
				}
			}
			result++;
//			int fireExtent = nBurnt - burnt;
//			System.out.println(fireExtent);
		}
		for (int x = 0; x < w; x++)
			for (int y = 0; y < h; y++) {
				double c = focalDrv.fireCount.getByInt(x, y);
				focalDec.fireFrequency.setByInt(c / time, x, y);
				int[] history = new int[fireHistory.size(2)];

				int now = (int) (time % history.length);
				for (int i = now; i < history.length; i++) {
					int f = focalDrv.fireHistory.getByInt(x, y, i);
					history[i - now] = f;
				}
				for (int i = 0; i < now; i++) {
					int f = focalDrv.fireHistory.getByInt(x, y, i);
					history[i + history.length - now] = f;
				}
				double hab = 1.0;
				for (int year = history.length - 1; year >= 0; year--) {
					if (history[year] == FIRE_LATE)
						hab = fireLateHabitatFunc.getByInt(year);
					if (history[year] == FIRE_EARLY)
						hab = fireEarlyHabitatFunc.getByInt(year);
				}
				focalDec.habitat.setByInt(hab, x, y);
			}

		focalDec.fireBurntFract = focalDec.fireBurntFract / (w * h);
		focalDec.fireEarlyFract = focalDec.fireEarlyFract / (w * h);
		focalDec.fireLateFract = focalDec.fireLateFract / (w * h);
		return result;

	}

	private static void burn(int x, int y, int z, int ft, FocalDec focalDec, FocalDrv focalDrv, IntTable fireCount,
			double time, DoubleTable fireEarlyHabitatFunc, DoubleTable fireLateHabitatFunc) {
		focalDec.fireType.setByInt(ft, x, y);
		focalDec.fireBurntFract++;
		focalDrv.fireCount.setByInt(fireCount.getByInt(x, y) + 1, x, y);
		if (ft == FIRE_EARLY)
			focalDec.fireEarlyFract++;
		else
			focalDec.fireLateFract++;
		focalDrv.fireHistory.setByInt(ft, x, y, z);
		double c = focalDrv.fireCount.getByInt(x, y);
		focalDec.fireFrequency.setByInt(c / time, x, y);

	}

	private static void spreadFrom(List<Integer> firelineX, List<Integer> firelineY, boolean[][] visited,
			double pSpread, Random random, int w, int h, boolean enterRef, BooleanTable refugia) {
		List<Integer> newfirelineX = new ArrayList<>();
		List<Integer> newfirelineY = new ArrayList<>();
		for (int i = 0; i < firelineX.size(); i++) {
			int x = firelineX.get(i);
			int y = firelineY.get(i);
			for (int dx = -1; dx <= 1; dx++)
				for (int dy = -1; dy <= 1; dy++)
					if (!(dy == 0 && dx == 0)) {
						int nx = x + dx;
						if (nx < 0)
							nx += w;
						nx = nx % w;
						int ny = y + dy;
						if (ny < 0)
							ny += h;
						ny = ny % h;
						if (!visited[nx][ny]) {
//							visited[nx][ny] = true;
							if (random.nextDouble() < pSpread) {
								boolean burn = true;
								if (!enterRef && refugia.getByInt(nx, ny))
									burn = false;
								if (burn) {
									visited[nx][ny] = true;
									newfirelineX.add(nx);
									newfirelineY.add(ny);
								}
							}
						}

					}
		}
		firelineX.clear();
		firelineY.clear();
		firelineX.addAll(newfirelineX);
		firelineY.addAll(newfirelineY);
	}
}
