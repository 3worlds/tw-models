package code.utilities;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import fr.cnrs.iees.omugi.collections.tables.BooleanTable;
import fr.cnrs.iees.omugi.collections.tables.IntTable;

public class UtilitiesGDDMR {
	private UtilitiesGDDMR() {
	};

	// Dimensioners are not passed to init functions. Therefore, update these if
	// they are changed.
	public static final double LANDSCAPE_WIDTH = 10000.0;
	public static final double LANDSCAPE_HEIGHT = 10000.0;
	public static final double HABITAT_CELL_SIZE = 100.0;
	public static final double DEME_CELL_SIZE = 10000.0 / 33.0;
	public static final int HABITAT_NO_FIRE = 0;
	public static final int HABITAT_EARLY_FIRE = 1;
	public static final int HABITAT_LATE_FIRE = 2;

	public static int gridLocation(double x, int extent, double gridSize) {
		int result = (int) (x / gridSize);
		result = result % extent;
		if (result < 0)
			result += extent;
		return result;
	}

	// Utilities3A.recordCensus((int)t,censusTime,Thread.currentThread().getId(),habitatLayer,ageInYears,xLocation,yLocation,alleles,isFemale);
	private static Map<Long, List<String>> censusData = null;
	private static Map<Long, String> expDesc = null;
	private final static String sep = "\t";
	private final static int censusTime = 100;
	// ! well really just hapliods and diploids
	private final static String[] ploidies = { "A", "B"};
	
	// not sure if sync means anything here.
	public synchronized static void recordCensus(int time, long threadId, BooleanTable habitatLayer, double ageInYears,
			double xLocation, double yLocation, IntTable alleles, boolean isFemale, boolean isDispersalInformed,
			boolean isDispersalShort, boolean habitatDynamic, boolean isHabitatFragmented) {
		if (time != censusTime)
			return;
		if (censusData == null) {
			censusData = new ConcurrentHashMap<>();
			expDesc = new ConcurrentHashMap<>();
		}

		int nLoci = alleles.size(0);
		int ploidy = alleles.size(1);
		int w = habitatLayer.size(0);
		int h = habitatLayer.size(1);

		List<String> lines = censusData.get(threadId);
		if (lines == null) {
			String exp = "";
			if (isDispersalShort)
				exp = "dd(short)";
			else
				exp = "dd(long)";
			if (isDispersalInformed)
				exp += "_dm(inf)";
			else
				exp += "_dm(uninf)";
			if (habitatDynamic)
				exp += "_hd(dyna)";
			else
				exp += "_hd(stat)";
			if (isHabitatFragmented)
				exp += "_hs(small)";
			else
				exp += "_hs(large)";
			expDesc.put(threadId, exp);

			lines = new ArrayList<String>();
			censusData.put(threadId, lines);
// #ALn1	ALn2
			StringBuilder sb = new StringBuilder().append("threadId").append(sep).append("sex").append(sep).append("age")
					.append(sep).append("x").append(sep).append("y").append(sep).append("habitat");
			for (int p = 0; p < ploidy; p++)
				for (int l = 0; l < nLoci; l++)
					sb.append(sep).append(ploidies[p]).append("Ln").append(l + 1);

			lines.add(sb.toString());
		}
		

		
		String sex = "f";
		if (!isFemale)
			sex = "m";
		int habitat=0;
		int ix = gridLocation(xLocation, w, HABITAT_CELL_SIZE);
		int iy = gridLocation(yLocation, h, HABITAT_CELL_SIZE);
		if (habitatLayer.getByInt(ix, iy))
			habitat = 1;

		StringBuilder sb = new StringBuilder().append(threadId).append(sep).append(sex).append(sep).append(ageInYears).append(sep)
				.append(xLocation).append(sep).append(yLocation).append(sep).append(habitat);
		for (int p = 0; p < ploidy; p++)
			for (int l = 0; l < nLoci; l++)
				sb.append(sep).append(alleles.getByInt(l, p));

		lines.add(sb.toString());

	}

	public static synchronized void  saveCensusToFile(int time, long threadId) {
		
		if (time != censusTime)
			return;
		if (censusData == null)
			return;
		
		List<String> lines = censusData.get(threadId);
		if (lines == null)
			return;
		// NB: Threads are not unique - it's a pool so they get recycled. Take care!
		censusData.remove(threadId);
		if (censusData.isEmpty())
			censusData = null;
		String fn = expDesc.get(threadId);
		expDesc.remove(threadId);
		if (expDesc.isEmpty())
			expDesc=null;
		
		int rep = 0;
		File file = new File(System.getProperty("user.home") + File.separator + "censusGDDM" + File.separator + fn + "_"
				+ "rp("+rep+")" + ".csv");
		file.getParentFile().mkdirs();
		
		while (file.exists()) {
			rep++;
			file = new File(System.getProperty("user.home") + File.separator + "censusGDDM" + File.separator + fn + "_"
					+ "rp("+rep+")" + ".csv");
		}
		try {
			Files.write(file.toPath(), lines, StandardCharsets.UTF_8);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
